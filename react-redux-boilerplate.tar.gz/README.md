Checkout this repo, install dependencies, then start the dev server with:

```
	> git clone git@github.com:wesleyahall/react-redux-boilerplate.git
	> cd ReduxSimpleStarter
	> npm install
	> npm run dev
```
